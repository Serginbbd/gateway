async function loadUser() {
  try {
    const data = await apiRequest("/me");

    document.getElementById("userName").innerText = data.user.name;
    document.getElementById("balance").innerText =
      Number(data.user.balance).toLocaleString("pt-BR", {
        style: "currency",
        currency: "BRL"
      });

  } catch (error) {
    logout();
  }
}

function buildPublicUrl(code) {
  return `${window.location.origin}/frontend/pay.html?code=${code}`;
}

async function loadPaymentLinks() {
  const data = await apiRequest("/payment-links");
  const tbody = document.getElementById("paymentLinkList");

  if (!data.links || data.links.length === 0) {
    tbody.innerHTML = `<tr><td colspan="5">Nenhum link criado.</td></tr>`;
    return;
  }

  tbody.innerHTML = data.links.map(link => {
    const url = buildPublicUrl(link.code);

    return `
      <tr>
        <td>${link.title}</td>
        <td>${Number(link.amount).toLocaleString("pt-BR", {
          style: "currency",
          currency: "BRL"
        })}</td>
        <td><span class="status">${link.status}</span></td>
        <td><input class="table-input" value="${url}" readonly></td>
        <td><button class="table-btn" onclick="copyText('${url}')">Copiar</button></td>
      </tr>
    `;
  }).join("");
}

const paymentLinkForm = document.getElementById("paymentLinkForm");

paymentLinkForm.addEventListener("submit", async (e) => {
  e.preventDefault();

  await apiRequest("/payment-links", {
    method: "POST",
    body: JSON.stringify({
      title: document.getElementById("title").value,
      amount: Number(document.getElementById("amount").value),
      description: document.getElementById("description").value
    })
  });

  paymentLinkForm.reset();
  loadPaymentLinks();
});

function copyText(text) {
  navigator.clipboard.writeText(text);
  alert("Link copiado!");
}

loadUser();
loadPaymentLinks();
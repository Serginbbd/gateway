async function loadDashboard() {
  try {
    const data = await apiRequest("/me");

    document.getElementById("userName").innerText = data.user.name;
    document.getElementById("helloName").innerText = data.user.name;

    const balance = Number(data.user.balance).toLocaleString("pt-BR", {
      style: "currency",
      currency: "BRL"
    });

    document.getElementById("balance").innerText = balance;
    document.getElementById("cardBalance").innerText = balance;

  } catch (error) {
    logout();
  }
}

loadDashboard();
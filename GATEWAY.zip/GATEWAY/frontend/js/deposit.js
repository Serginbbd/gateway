async function loadUser() {
  try {
    const data = await apiRequest("/me");

    document.getElementById("userName").innerText = data.user.name;

    const balance = Number(data.user.balance).toLocaleString("pt-BR", {
      style: "currency",
      currency: "BRL"
    });

    document.getElementById("balance").innerText = balance;

  } catch (error) {
    logout();
  }
}

function setAmount(value) {
  document.getElementById("amount").value = value;
}

const depositForm = document.getElementById("depositForm");

depositForm.addEventListener("submit", async (e) => {
  e.preventDefault();

  const amount = Number(document.getElementById("amount").value);
  const cpf = document.getElementById("cpf").value;

  try {
    const data = await apiRequest("/deposits", {
      method: "POST",
      body: JSON.stringify({
        amount,
        cpf
      })
    });

    document.getElementById("pixResult").innerHTML = `
      <div class="generated-pix">
        <h2>Pix gerado com sucesso</h2>
        <p>Escaneie o QR Code ou copie o código Pix.</p>

        <div class="generated-qr">
          ${
            data.qrCode
              ? `<img src="${data.qrCode}" width="100%" height="100%">`
              : `<div class="qr-placeholder"></div>`
          }
        </div>

        <strong>Valor: ${amount.toLocaleString("pt-BR", {
          style: "currency",
          currency: "BRL"
        })}</strong>

        <div class="pix-code-box" id="pixCode">
          ${data.copiaECola || data.pixCode || "Código Pix será exibido aqui"}
        </div>

        <button class="copy-pix-btn" onclick="copyPix()">Copiar código Pix</button>
      </div>
    `;

    loadDeposits();

  } catch (error) {
    alert(error.message);
  }
});

function copyPix() {
  const code = document.getElementById("pixCode").innerText;
  navigator.clipboard.writeText(code);
  alert("Código Pix copiado!");
}

async function loadDeposits() {
  try {
    const data = await apiRequest("/deposits");

    const tbody = document.getElementById("depositList");

    if (!data.deposits || data.deposits.length === 0) {
      tbody.innerHTML = `
        <tr>
          <td colspan="4">Nenhum depósito encontrado.</td>
        </tr>
      `;
      return;
    }

    tbody.innerHTML = data.deposits.map(dep => `
      <tr>
        <td>#${dep.id}</td>
        <td>${Number(dep.amount).toLocaleString("pt-BR", {
          style: "currency",
          currency: "BRL"
        })}</td>
        <td><span class="status">${dep.status}</span></td>
        <td>${new Date(dep.created_at).toLocaleString("pt-BR")}</td>
      </tr>
    `).join("");

  } catch (error) {
    console.log(error);
  }
}

loadUser();
loadDeposits();
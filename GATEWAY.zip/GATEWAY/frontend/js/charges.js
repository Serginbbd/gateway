async function loadUser() {
  try {
    const data = await apiRequest("/me");

    document.getElementById("userName").innerText = data.user.name;
    document.getElementById("balance").innerText =
      Number(data.user.balance).toLocaleString("pt-BR", {
        style: "currency",
        currency: "BRL"
      });

  } catch (error) {
    logout();
  }
}

async function loadClientsSelect() {
  const data = await apiRequest("/clients");
  const select = document.getElementById("client_id");

  data.clients.forEach(client => {
    const option = document.createElement("option");
    option.value = client.id;
    option.textContent = client.name;
    select.appendChild(option);
  });
}

async function loadCharges() {
  const data = await apiRequest("/charges");
  const tbody = document.getElementById("chargeList");

  if (!data.charges || data.charges.length === 0) {
    tbody.innerHTML = `<tr><td colspan="5">Nenhuma cobrança cadastrada.</td></tr>`;
    return;
  }

  tbody.innerHTML = data.charges.map(charge => `
    <tr>
      <td>${charge.client_name || '-'}</td>
      <td>${charge.title || '-'}</td>
      <td>${Number(charge.amount).toLocaleString("pt-BR", {
        style: "currency",
        currency: "BRL"
      })}</td>
      <td>${charge.due_date ? new Date(charge.due_date).toLocaleDateString("pt-BR") : '-'}</td>
      <td><span class="status">${charge.status}</span></td>
    </tr>
  `).join("");
}

const chargeForm = document.getElementById("chargeForm");

chargeForm.addEventListener("submit", async (e) => {
  e.preventDefault();

  await apiRequest("/charges", {
    method: "POST",
    body: JSON.stringify({
      client_id: document.getElementById("client_id").value || null,
      title: document.getElementById("title").value,
      amount: Number(document.getElementById("amount").value),
      due_date: document.getElementById("due_date").value || null
    })
  });

  chargeForm.reset();
  loadCharges();
});

loadUser();
loadClientsSelect();
loadCharges();
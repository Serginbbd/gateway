const params = new URLSearchParams(window.location.search);
const code = params.get("code");

async function loadPaymentLink() {
  try {
    const response = await fetch(`http://localhost:3000/public/payment-link/${code}`);
    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.error || "Link inválido");
    }

    document.getElementById("payTitle").innerText = data.link.title;
    document.getElementById("payDescription").innerText = data.link.description || "";
    document.getElementById("payAmount").innerText =
      Number(data.link.amount).toLocaleString("pt-BR", {
        style: "currency",
        currency: "BRL"
      });

    document.getElementById("payButton").onclick = () => {
      alert("Na próxima etapa, este botão vai gerar o Pix pela sua API de pagamento.");
    };

  } catch (error) {
    document.getElementById("payTitle").innerText = "Link indisponível";
    document.getElementById("payDescription").innerText = error.message;
    document.getElementById("payButton").style.display = "none";
  }
}

loadPaymentLink();
async function loadUser() {
  try {
    const data = await apiRequest("/me");

    document.getElementById("userName").innerText = data.user.name;

    document.getElementById("balance").innerText =
      Number(data.user.balance).toLocaleString("pt-BR", {
        style: "currency",
        currency: "BRL"
      });

  } catch (error) {
    logout();
  }
}

async function loadClients() {
  try {
    const data = await apiRequest("/clients");
    const tbody = document.getElementById("clientList");

    if (!data.clients || data.clients.length === 0) {
      tbody.innerHTML = `<tr><td colspan="5">Nenhum cliente cadastrado.</td></tr>`;
      return;
    }

    tbody.innerHTML = data.clients.map(client => `
      <tr>
        <td>${client.name}</td>
        <td>${client.email || '-'}</td>
        <td>${client.cpf || '-'}</td>
        <td>${client.phone || '-'}</td>
        <td><span class="status">${client.status}</span></td>
      </tr>
    `).join("");

  } catch (error) {
    alert(error.message);
  }
}

const clientForm = document.getElementById("clientForm");

clientForm.addEventListener("submit", async (e) => {
  e.preventDefault();

  try {
    await apiRequest("/clients", {
      method: "POST",
      body: JSON.stringify({
        name: document.getElementById("name").value,
        email: document.getElementById("email").value,
        cpf: document.getElementById("cpf").value,
        phone: document.getElementById("phone").value
      })
    });

    clientForm.reset();
    loadClients();

  } catch (error) {
    alert(error.message);
  }
});

loadUser();
loadClients();
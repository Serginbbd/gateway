require('dotenv').config();
const chargeRoutes = require('./routes/charge.routes');
const userRoutes = require('./routes/user.routes');
const express = require('express');
const cors = require('cors');
const authRoutes = require('./routes/auth.routes');
const db = require('./config/db');
const clientRoutes = require('./routes/client.routes');
const paymentLinkRoutes = require('./routes/paymentLink.routes');
const app = express();

app.use(cors());
app.use(express.json());
app.use('/auth', authRoutes);
app.use('/', userRoutes);
app.use('/', clientRoutes);
app.use('/', chargeRoutes);

db.query('SELECT NOW()')
    .then(() => {
        console.log('✅ Banco conectado com sucesso');
    })
    .catch((err) => {
        console.log('❌ Erro ao conectar banco');
        console.error(err);
    });

app.get('/', (req, res) => {
    res.json({
        status: 'online',
        database: 'connected'
    });
});

const PORT = process.env.PORT || 3000;

app.listen(PORT, () => {
    console.log(`🚀 Servidor rodando na porta ${PORT}`);
});
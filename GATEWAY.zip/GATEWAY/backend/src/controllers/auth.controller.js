const db = require('../config/db');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

exports.register = async (req, res) => {
    try {
        const { name, email, password } = req.body;

        const userExists = await db.query(
            'SELECT * FROM users WHERE email = $1',
            [email]
        );

        if (userExists.rows.length > 0) {
            return res.status(400).json({
                error: 'Usuário já existe'
            });
        }

        const hash = await bcrypt.hash(password, 10);

        const user = await db.query(
            `INSERT INTO users
            (name, email, password_hash)
            VALUES ($1, $2, $3)
            RETURNING id, name, email, balance, role`,
            [name, email, hash]
        );

        return res.status(201).json({
            success: true,
            user: user.rows[0]
        });

    } catch (error) {
        console.error(error);

        return res.status(500).json({
            error: 'Erro interno'
        });
    }
};

exports.login = async (req, res) => {
    try {
        const { email, password } = req.body;

        const userResult = await db.query(
            'SELECT * FROM users WHERE email = $1',
            [email]
        );

        if (userResult.rows.length === 0) {
            return res.status(401).json({
                error: 'Usuário não encontrado'
            });
        }

        const user = userResult.rows[0];

        const validPassword = await bcrypt.compare(
            password,
            user.password_hash
        );

        if (!validPassword) {
            return res.status(401).json({
                error: 'Senha inválida'
            });
        }

        const token = jwt.sign(
            {
                id: user.id,
                email: user.email
            },
            process.env.JWT_SECRET,
            {
                expiresIn: '7d'
            }
        );

        return res.json({
            success: true,
            token,
            user: {
                id: user.id,
                name: user.name,
                email: user.email,
                balance: user.balance,
                role: user.role
            }
        });

    } catch (error) {
        console.error(error);

        return res.status(500).json({
            error: 'Erro interno'
        });
    }
};
const { Pool } = require('pg');

const pool = new Pool({
    user: 'postgres',
    password: '070522',
    host: 'localhost',
    port: 5432,
    database: 'gateway_db'
});

module.exports = pool;  
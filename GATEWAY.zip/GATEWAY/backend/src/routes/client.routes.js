const express = require('express');
const router = express.Router();

const db = require('../config/db');
const authMiddleware = require('../middleware/auth.middleware');

router.get('/clients', authMiddleware, async (req, res) => {
    try {
        const clients = await db.query(
            'SELECT * FROM clients WHERE user_id = $1 ORDER BY created_at DESC',
            [req.user.id]
        );

        return res.json({
            success: true,
            clients: clients.rows
        });

    } catch (error) {
        console.error(error);
        return res.status(500).json({ error: 'Erro ao buscar clientes' });
    }
});

router.post('/clients', authMiddleware, async (req, res) => {
    try {
        const { name, email, cpf, phone } = req.body;

        const client = await db.query(
            `INSERT INTO clients 
            (user_id, name, email, cpf, phone)
            VALUES ($1, $2, $3, $4, $5)
            RETURNING *`,
            [req.user.id, name, email, cpf, phone]
        );

        return res.status(201).json({
            success: true,
            client: client.rows[0]
        });

    } catch (error) {
        console.error(error);
        return res.status(500).json({ error: 'Erro ao cadastrar cliente' });
    }
});

module.exports = router;
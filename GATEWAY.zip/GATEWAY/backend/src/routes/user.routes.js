const express = require('express');
const router = express.Router();

const db = require('../config/db');
const authMiddleware = require('../middleware/auth.middleware');

router.get('/me', authMiddleware, async (req, res) => {
    try {
        const user = await db.query(
            'SELECT id, name, email, balance, role FROM users WHERE id = $1',
            [req.user.id]
        );

        if (user.rows.length === 0) {
            return res.status(404).json({ error: 'Usuário não encontrado' });
        }

        return res.json({
            success: true,
            user: user.rows[0]
        });

    } catch (error) {
        console.error(error);
        return res.status(500).json({ error: 'Erro interno' });
    }
});

module.exports = router;
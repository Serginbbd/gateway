const express = require('express');
const router = express.Router();

const db = require('../config/db');
const authMiddleware = require('../middleware/auth.middleware');

function generateCode() {
    return 'pay_' + Math.random().toString(36).substring(2, 12);
}

router.get('/payment-links', authMiddleware, async (req, res) => {
    try {
        const links = await db.query(
            'SELECT * FROM payment_links WHERE user_id = $1 ORDER BY created_at DESC',
            [req.user.id]
        );

        res.json({ success: true, links: links.rows });

    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Erro ao buscar links' });
    }
});

router.post('/payment-links', authMiddleware, async (req, res) => {
    try {
        const { title, amount, description } = req.body;
        const code = generateCode();

        const link = await db.query(
            `INSERT INTO payment_links
            (user_id, title, amount, description, code)
            VALUES ($1, $2, $3, $4, $5)
            RETURNING *`,
            [req.user.id, title, amount, description, code]
        );

        res.status(201).json({
            success: true,
            link: link.rows[0],
            url: `http://localhost:5500/frontend/pay.html?code=${code}`
        });

    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Erro ao criar link de pagamento' });
    }
});

router.get('/public/payment-link/:code', async (req, res) => {
    try {
        const { code } = req.params;

        const link = await db.query(
            `SELECT id, title, amount, description, status, code
             FROM payment_links
             WHERE code = $1`,
            [code]
        );

        if (link.rows.length === 0) {
            return res.status(404).json({ error: 'Link não encontrado' });
        }

        res.json({ success: true, link: link.rows[0] });

    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Erro ao buscar link' });
    }
});

module.exports = router;
const express = require('express');
const router = express.Router();

const db = require('../config/db');
const authMiddleware = require('../middleware/auth.middleware');

router.get('/charges', authMiddleware, async (req, res) => {
    try {
        const charges = await db.query(
            `SELECT charges.*, clients.name AS client_name
             FROM charges
             LEFT JOIN clients ON clients.id = charges.client_id
             WHERE charges.user_id = $1
             ORDER BY charges.created_at DESC`,
            [req.user.id]
        );

        return res.json({ success: true, charges: charges.rows });

    } catch (error) {
        console.error(error);
        return res.status(500).json({ error: 'Erro ao buscar cobranças' });
    }
});

router.post('/charges', authMiddleware, async (req, res) => {
    try {
        const { client_id, title, amount, due_date } = req.body;

        const charge = await db.query(
            `INSERT INTO charges
            (user_id, client_id, title, amount, due_date)
            VALUES ($1, $2, $3, $4, $5)
            RETURNING *`,
            [req.user.id, client_id || null, title, amount, due_date || null]
        );

        return res.status(201).json({
            success: true,
            charge: charge.rows[0]
        });

    } catch (error) {
        console.error(error);
        return res.status(500).json({ error: 'Erro ao criar cobrança' });
    }
});

module.exports = router;